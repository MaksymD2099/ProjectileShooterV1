/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projectileshooter;

import java.awt.Point;
import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;
import javafx.animation.AnimationTimer;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.geometry.Bounds;
import javafx.scene.Node;
import javafx.scene.control.Label;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Rectangle;

/**
 *
 * @author cstuser
 */
public class FXMLDocumentController implements Initializable {

    private double lastFrameTime = 0.0;

    @FXML
    private Label coordinates;
    
    @FXML
    private ImageView gunImage;
    
    @FXML
    private ImageView character;

    @FXML
    private AnchorPane pane;



    //Local Variables
    ArrayList<Double> values = new ArrayList<Double>();
    public ArrayList<GameObject> objectList = new ArrayList<>();
    
    //rectangles for detecting collisions with the edges of the game environment
    private Edge edgeRoof;     
    private Edge edgeFloor;
    private Edge edgeLeftWall;
    private Edge edgeRightWall;
    
    
    //private Gun gun;
    private boolean increasing = true;
    
    //Boolean to check if the projectile is within the bounds of an antigravity region    
    private boolean isWithinGravity = false;
    //private boolean decreasing = false;

    public Point mouseAim;
    public Point gunPivot;
    
    //Variables for the mouse's position within the game environment    
    private double mouseX;
    private double mouseY;
    
    private Vector velocityProjectile;
    private Projectile projectile;
    
    private final double PROJECTILE_RADIUS = 10;
    //private final double PROJECTILE_VELOCITY;
            
    
    
    
    private Vector acceleration;


    public void addToPane(Node node) {
        pane.getChildren().add(node);
    }

    public void removeFromPane(Node node) {
        pane.getChildren().remove(node);
    }

    @FXML    
    public void mouseMoved(MouseEvent event) {

        mouseX = event.getSceneX();
        mouseY = (pane.getHeight() - event.getSceneY());
        
      // double theta = Math.atan(x/y);
      // double degrees = Math.toDegrees(theta);

      /* isIncreasing(degrees);

        if(increasing)
        {
            System.out.println("++Positive");
            degrees = + degrees;
        }else{
            System.out.println("--Negative");
           // degrees = - degrees;
        }*/

        mouseAim = new Point((int)mouseX,(int)mouseY);       
        gunRotationAngle(mouseAim, gunPivot);
        
        coordinates.setText("MouseX: " + mouseX + "MouseY: " + mouseY);
        //gunRotation(degrees - 90);
    }
    
    @FXML
    public void mouseClicked(MouseEvent event)
    {
        /*
        if(isWithinGravity)
        {
            acceleration = new Vector(0, -20);
        }
        */
        
        mouseX = event.getSceneX();
        mouseY = event.getSceneY();
        
        acceleration = new Vector(0, 20);
        //if(gunImage.getType() == "fire....")
        
        //This is for trying to get the velocity of the projectile to be prpoportional to the mouse's position
        //projectile = new Projectile(new Vector(2*gunImage.getLayoutX(), gunImage.getLayoutY()),new Vector(mouseX/Math.hypot(mouseX, mouseY), -mouseY/-Math.hypot(mouseX, mouseY)), acceleration, PROJECTILE_RADIUS, "fire");
        projectile = new Projectile(new Vector(2*gunImage.getLayoutX(), gunImage.getLayoutY()),new Vector(mouseX, -mouseY), acceleration, PROJECTILE_RADIUS, "fire");
        addToPane(projectile.getCircle());
        objectList.add(projectile);        
    }

    public void isIncreasing(double degrees)
    {
        double degrees_rounded = Math.round(degrees * 100)/100.0;
        values.add(degrees_rounded);


             for (int i = 0; i < values.size() - 1; i++) {
               if(values.size() > 1){

                  if(values.get(i+1) > values.get(i))
                  {
                      increasing = true;

                        if(values.size() == 2)
                         {
                            values.remove(0);
                         }

                  }else{
                      increasing = false;

                        if(values.size() == 2)
                         {
                            values.remove(0);
                         }
                       }
              }
         }
    }


      public void gunRotation(double degrees)
      {
          //Object Gun
          /*Rectangle rec = gun.getRectangle();
          Rotate rotate = new Rotate(degrees, 20, 800);
          rec.getTransforms().addAll(rotate);          
          rec.setRotationAxis(Point3D.ZERO);
          rec.setRotate(degrees);*/
          
          //ImageGun
          //gunImage.setRotationAxis(Point3D.ZERO);
          //gunImage.setRotate(degrees);
      }
      
      public void gunRotationAngle(Point mouseAim, Point gunPivot)
      {                  
        double theta = Math.atan2(mouseAim.y - gunPivot.y, mouseAim.x - gunPivot.x);
        double angle = Math.toDegrees(theta);
        System.out.println(angle + "");
        //gunImage.setRotationAxis(new Point3D(gunImage, gunImage.getTranslateY(), gunImage.getTranslateZ()));
        gunImage.setRotate(-angle);
        //gunImage.setRotationAxis(new Point3D(new Vector(0,0)));
      }


    @Override
    public void initialize(URL url, ResourceBundle rb) {
        lastFrameTime = 0.0f;
        long initialTime = System.nanoTime();

        AssetManager.preloadAllAssets();

       //Object Gun
       //gun = new Gun(new Vector(20,800), 90 , 50 , "fire");
       //addToPane(gun.getRectangle());
       
       //Image of MainCharacter
       character.setImage(AssetManager.getCharacterImage());      
       
       //Image Gun
        gunImage.setImage(AssetManager.getGunFire_Img());
        

        //gunImage.rotationAxisProperty().set(new Point3D(0,0,0));
        
        //gunImage.setRotationAxis(new Point3D(0,0,0));        
        gunPivot = new Point();
        gunPivot.setLocation(100, 100);
        
        edgeFloor = new Edge(new Vector(50, 50), 200, -150);        
        edgeRoof = new Edge(new Vector(50, 50), 142, -75);
        edgeLeftWall = new Edge(new Vector(200, 50), 300, -250);
        edgeRightWall = new Edge(new Vector(50, 50), 600, -700);
        
        edgeFloor.getRectangle().setFill(AssetManager.getEdgePattern());
        edgeRoof.getRectangle().setFill(AssetManager.getEdgePattern());
        edgeLeftWall.getRectangle().setFill(AssetManager.getEdgePattern());
        edgeRightWall.getRectangle().setFill(AssetManager.getEdgePattern());
        
        //Adding edges to the pane so that collisions can be detected with the edge        
        addToPane(edgeFloor.getRectangle());
        addToPane(edgeRoof.getRectangle());
        addToPane(edgeLeftWall.getRectangle());
        addToPane(edgeRightWall.getRectangle());
        
        //Adding edges to the objectList so that their existance within the program can be monitored                
       /* objectList.add(edgeFloor);
        objectList.add(edgeRoof);
        objectList.add(edgeRightWall);
        objectList.add(edgeLeftWall);*/
      
        new AnimationTimer() {
            @Override
            public void handle(long now)
            {
                try{
            double currentTime = (now - initialTime) / 1000000000.0;
            double frameDeltaTime = currentTime - lastFrameTime;
            lastFrameTime = currentTime;
            
            for (GameObject obj : objectList) {
                if (obj != null) 
                {
                    obj.updateCircle(frameDeltaTime);
                    obj.updateRectangle(frameDeltaTime);
                }
            }                       
        }catch(Exception e){} 
            //Set the bounds of the game objects
            //Create class variables for each game object's bounds            
            /*
            Circle projectileCircle = projectile.getCircle();
            Bounds boundProjectileCircle = projectileCircle.getBoundsInParent();
            
            //Setting bounds for the edges of the game environment
            //Bounds of floor
            Rectangle rectangleEdgeFloor = edgeFloor.getRectangle();
            Bounds boundRectangleEdgeFloor = rectangleEdgeFloor.getBoundsInParent();
            
            //Bounds of Roof
            Rectangle rectangleEdgeRoof = edgeRoof.getRectangle();
            Bounds boundRectangleEdgeRoof = rectangleEdgeRoof.getBoundsInParent();
            
            //Bounds of Left Wall
            Rectangle rectangleEdgeLeftWall = edgeLeftWall.getRectangle();
            Bounds boundRectangleEdgeLeftWall = rectangleEdgeLeftWall.getBoundsInParent();
            
            //Bounds of Right Wall
            Rectangle rectangleEdgeRightWall = edgeRightWall.getRectangle();
            Bounds boundRectangleEdgeRightWall = rectangleEdgeRightWall.getBoundsInParent();
            
            //If statments that check if the projectiles have collided with the edges of the game environment
            if(boundProjectileCircle.intersects(boundRectangleEdgeFloor) || boundProjectileCircle.intersects(boundRectangleEdgeRoof))
            {
                //put if() statments to check for collision between antigravity and portals with the edges
                AssetManager.getBounce().play();
                projectile.setVelocity(new Vector(projectile.getVelocity().getX(), -projectile.getVelocity().getY()));                        
            }            
            if(boundProjectileCircle.intersects(boundRectangleEdgeLeftWall)|| boundProjectileCircle.intersects(boundRectangleEdgeRightWall))
            {
                AssetManager.getBounce().play();
                projectile.setVelocity(new Vector(-projectile.getVelocity().getX(), projectile.getVelocity().getY()));                                                        
            }*/
        }
}.start();
}
}



  /*
            
             if (prj_rec_Bounds.intersects(shield_rec_Bounds1) || prj_rec_Bounds.intersects(shield_rec_Bounds2) || prj_rec_Bounds.intersects(shield_rec_Bounds3)) {

                        AssetManager.getEnnemyHitSound().play();

                        pane.getChildren().remove(projectiles_enemy.get(i).getRectangle());
                        projectiles_enemy.remove(i);

                    } else if (prj_rec.getY() + prj_rec.getHeight() > pane.getHeight() || prj_rec.getY() < 0) {
                        pane.getChildren().remove(projectiles_enemy.get(i).getRectangle());
                        projectiles_enemy.remove(i);
                    }
*/
